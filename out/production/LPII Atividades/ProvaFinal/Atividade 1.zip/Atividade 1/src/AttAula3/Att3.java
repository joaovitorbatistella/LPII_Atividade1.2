package AttAula3;

import java.util.Scanner;

public class Att3 {
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);


    }
}
