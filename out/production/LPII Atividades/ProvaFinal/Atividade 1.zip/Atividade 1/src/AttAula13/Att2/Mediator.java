package AttAula13.Att2;

public interface Mediator {
    void enviar(String mensagem, Colleague colleague);
}
