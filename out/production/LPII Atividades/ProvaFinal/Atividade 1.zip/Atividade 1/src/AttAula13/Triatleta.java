package AttAula13;

public class Triatleta {

    public Triatleta() {

    }
    public void correr() {
        System.out.println("Coorendo");
    }
    public void pedalar() {
        System.out.println("Pedalando");
    }
    public void nadar() {
        System.out.println("Nadando");
    }
}
