package AttAula13;

public class Ciclista extends Triatleta {

    public void pedalar() {

    }

}
