package AttAula13;

public class Pessoa {
    private String nome;

    public Pessoa() {
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String val) {
        this.nome = val;
    }
}
