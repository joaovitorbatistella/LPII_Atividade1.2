package AttAula13;

public class Main {
    public static void main(String[] args) {
        Triatleta triatleta1 = new Triatleta();
        triatleta1.correr();
        triatleta1.pedalar();
        triatleta1.nadar();

        Pessoa pessoa1 = new Pessoa();
    }
}
