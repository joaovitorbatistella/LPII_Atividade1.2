package AttAula13;

public class Corredor extends Triatleta {

    public void correr() {

    }
}
