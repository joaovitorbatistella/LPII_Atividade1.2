package AttAula13;

public class Nadador extends Triatleta {

    public void nadar() {

    }
}
