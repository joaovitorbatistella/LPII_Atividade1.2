package AttAula10.Att1;

public class Pessoas {
    String nome;
    int idade;

    public Pessoas(String nome, int idade){
        this.idade = idade;
        this.nome = nome;
    }
}
