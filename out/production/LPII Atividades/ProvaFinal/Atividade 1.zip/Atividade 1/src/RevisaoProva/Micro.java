package RevisaoProva;

public class Micro extends Veiculo {
    public Micro() {
        this.setCapacidade(23);
    }
}
