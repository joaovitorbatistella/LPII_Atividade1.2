package RevisaoProva;

public class Van extends Veiculo{
    public Van() {
        this.setCapacidade(15);
    }
}
