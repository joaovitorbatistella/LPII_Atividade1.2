package RevisaoProva;

public class Onibus extends Veiculo {
    public Onibus() {
        this.setCapacidade(40);
    }
}
