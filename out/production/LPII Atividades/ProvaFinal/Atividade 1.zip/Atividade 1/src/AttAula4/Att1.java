package AttAula4;

public class Att1 {
    public static void main(String[] args){

        String frase = "Socorram-me, subi no ônibus em Marrocos", fraseInvertida[];

        fraseInvertida = frase.split(" ");

        System.out.println(fraseInvertida[5] + " " + fraseInvertida[4] + " " + fraseInvertida[3] + " " +  fraseInvertida[2] + " " + fraseInvertida[1] + " " + fraseInvertida[0]);

    }
}
