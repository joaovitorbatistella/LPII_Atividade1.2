package AttAula11.Att1_2_3;

public class Veterinario{

    public void examinar(Animal animal) {
        animal.emitirSom();
    }
}
